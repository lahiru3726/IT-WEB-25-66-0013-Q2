﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using StudentRegistrationDetails.Data;
using StudentRegistrationDetails.Mdels;

namespace StudentRegistrationDetails.Pages.Rgistration
{
    public class IndexModel : PageModel
    {
        private readonly StudentRegistrationDetails.Data.StudentRegistrationDetailsContext _context;

        public IndexModel(StudentRegistrationDetails.Data.StudentRegistrationDetailsContext context)
        {
            _context = context;
        }

        public IList<studentData> studentData { get;set; } = default!;

        public async Task OnGetAsync()
        {
            studentData = await _context.Data.ToListAsync();
        }
    }
}
