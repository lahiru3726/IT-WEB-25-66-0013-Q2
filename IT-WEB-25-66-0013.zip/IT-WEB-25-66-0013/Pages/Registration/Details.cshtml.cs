﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using StudentRegistrationDetails.Data;
using StudentRegistrationDetails.Mdels;

namespace StudentRegistrationDetails.Pages.Rgistration
{
    public class DetailsModel : PageModel
    {
        private readonly StudentRegistrationDetails.Data.StudentRegistrationDetailsContext _context;

        public DetailsModel(StudentRegistrationDetails.Data.StudentRegistrationDetailsContext context)
        {
            _context = context;
        }

        public studentData studentData { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var studentdata = await _context.Data.FirstOrDefaultAsync(m => m.id == id);

            if (studentdata is not null)
            {
                studentData = studentdata;

                return Page();
            }

            return NotFound();
        }
    }
}
