﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using StudentRegistrationDetails.Data;
using StudentRegistrationDetails.Mdels;

namespace StudentRegistrationDetails.Pages.Rgistration
{
    public class DeleteModel : PageModel
    {
        private readonly StudentRegistrationDetails.Data.StudentRegistrationDetailsContext _context;

        public DeleteModel(StudentRegistrationDetails.Data.StudentRegistrationDetailsContext context)
        {
            _context = context;
        }

        [BindProperty]
        public studentData studentData { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var studentdata = await _context.Data.FirstOrDefaultAsync(m => m.id == id);

            if (studentdata is not null)
            {
                studentData = studentdata;

                return Page();
            }

            return NotFound();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var studentdata = await _context.Data.FindAsync(id);
            if (studentdata != null)
            {
                studentData = studentdata;
                _context.Data.Remove(studentData);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
