﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using StudentRegistrationDetails.Mdels;

namespace StudentRegistrationDetails.Data
{
    public class StudentRegistrationDetailsContext : DbContext
    {
        public StudentRegistrationDetailsContext (DbContextOptions<StudentRegistrationDetailsContext> options)
            : base(options)
        {
        }

        public DbSet<StudentRegistrationDetails.Mdels.studentData> Data { get; set; } = default!;
    }
}
