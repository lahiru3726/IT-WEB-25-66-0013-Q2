﻿namespace StudentRegistrationDetails.Mdels
{
    public class studentData
    {
        public int id { get; set; }
        public int course_id { get; set; }
        public int student_id { get; set; }
        public string course_name{ get; set; }
        public string student_name { get; set; }
        public string city { get; set; }
        public string Lecturer_Name { get; set; }

    }
}
